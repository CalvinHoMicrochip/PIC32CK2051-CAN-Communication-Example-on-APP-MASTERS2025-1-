/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "OLED128x64.h"

#define         CAN_TXID        0x300 
#define         CAN_RXID        0x200
#define         HOW_MANY_100MS  2

#define         WRITE_ID(id)    (id << 18)
#define         READ_ID(id)     (id >> 18)

uint8_t Can1MessageRAM[CAN1_MESSAGE_RAM_CONFIG_SIZE] __attribute__((aligned (32)));

static uint8_t      txFiFo[CAN1_TX_FIFO_BUFFER_SIZE];
static uint8_t      rxFiFo0[CAN1_RX_FIFO0_SIZE];
volatile bool       bIsI2C_DONE = 1 ;
volatile bool       bIsTimeout = 0;

uint16_t            adcResult = 0;
volatile uint8_t     TickCounter = 0 ;

void            Transmit_CAN1_Message(void) ;
uint16_t        Receive_CAN_Message(void);

volatile uint16_t        CAN_ReceiveCounter = 0 ;
volatile uint16_t        NewPWM = 0 ;
unsigned char            ASCII_Buffer[64] ;

void    I2C_EventHandler(uintptr_t  contest)
{
    if (SERCOM5_I2C_ErrorGet() == SERCOM_I2C_ERROR_NONE )
        bIsI2C_DONE = true ;
}

void SYSTICK_EventHandler(uintptr_t context)
{
    /* Toggle LED */
    
    TickCounter ++ ;
    if (TickCounter >=  HOW_MANY_100MS)
    {
        LED2_Toggle();
        bIsTimeout = 1 ;    
        TickCounter = 0 ;
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    SYSTICK_TimerCallbackSet( SYSTICK_EventHandler,(uintptr_t ) NULL );
    
     SERCOM5_I2C_CallbackRegister(I2C_EventHandler,0) ;    
     SYSTICK_TimerStart();         
     
     bIsTimeout = 0 ;
     while (bIsTimeout == 0) ;
     
        OLED_Init();
        OLED_CLS();
        OLED_Put8x16Str(0, 0, (const unsigned char*) "PIC32CK CAN Test") ;       
        sprintf(ASCII_Buffer,"TID=%x  RID=%x",CAN_TXID,CAN_RXID);
        OLED_Put8x16Str(0,2,ASCII_Buffer) ;      
        TCC4_PWMStart();
        CAN1_MessageRAMConfigSet(Can1MessageRAM);                   // Important ... To allocate correct RAM Buffer for CAN Buffers

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        
        Receive_CAN_Message();
                   
        if (bIsTimeout)
        {
            bIsTimeout = 0 ;
            
            
            ADC_GlobalEdgeConversionStart();
            while(!ADC_ChannelResultIsReady(ADC_CH3));
            adcResult = ADC_ResultGet(ADC_CH3);                        
            // TCC4_PWM16bitDutySet(TCC4_CHANNEL0,adcResult); 
            TCC4_PWM16bitDutySet(TCC4_CHANNEL0,NewPWM);            
            sprintf(ASCII_Buffer,"CANRX Cntr:%5d",CAN_ReceiveCounter);
            OLED_Put8x16Str(0,4,ASCII_Buffer) ;           
            sprintf(ASCII_Buffer,"Get VR :%5d",NewPWM );
            OLED_Put8x16Str(0,6,ASCII_Buffer) ;                     
            Transmit_CAN1_Message();
        }
        
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}

static uint8_t CANLengthToDlcGet(uint8_t length)
{
    uint8_t dlc = 0;

    if (length <= 8U)
    {
        dlc = length;
    }
    else if (length <= 12U)
    {
        dlc = 0x9U;
    }
    else if (length <= 16U)
    {
        dlc = 0xAU;
    }
    else if (length <= 20U)
    {
        dlc = 0xBU;
    }
    else if (length <= 24U)
    {
        dlc = 0xCU;
    }
    else if (length <= 32U)
    {
        dlc = 0xDU;
    }
    else if (length <= 48U)
    {
        dlc = 0xEU;
    }
    else
    {
        dlc = 0xFU;
    }
    return dlc;
}

uint16_t Receive_CAN_Message(void)
{
    CAN_RX_BUFFER *rxBuffer = NULL; 
    uint8_t        numberOfMessage = 0; 
    static uint32_t     CANStatus = 0;
    static uint32_t     ReceivedID  ;
    uint16_t            ReturnValue = 0 ;
    
      if (CAN1_InterruptGet(CAN_INTERRUPT_RF0N_MASK))
        {    
            CAN1_InterruptClear(CAN_INTERRUPT_RF0N_MASK);

            /* Check CAN Status */
            CANStatus = CAN1_ErrorGet();
            if (((CANStatus & CAN_PSR_LEC_Msk) == CAN_ERROR_NONE) || ((CANStatus & CAN_PSR_LEC_Msk) == CAN_ERROR_LEC_NC))
            {
                numberOfMessage = CAN1_RxFifoFillLevelGet(CAN_RX_FIFO_0);
                if (numberOfMessage != 0)
                {
                    memset(rxFiFo0, 0x00, (numberOfMessage * CAN1_RX_FIFO0_ELEMENT_SIZE));
                    // if (CAN0_MessageReceiveFifo(CAN_RX_FIFO_0, numberOfMessage, (CAN_RX_BUFFER *)rxFiFo) == true)
                    // CAN0 : Read Buffer one by one 
                    if (CAN1_MessageReceiveFifo(CAN_RX_FIFO_0, 1, (CAN_RX_BUFFER *)rxFiFo0) == true)
                    {
                        rxBuffer = (CAN_RX_BUFFER *)rxFiFo0;     
                            ReceivedID = READ_ID(rxBuffer->id);                                                               
                            if (ReceivedID == CAN_RXID)
                            {
                                    CAN_ReceiveCounter += 1 ;
                                    ReturnValue = ((uint16_t) rxBuffer->data[3] * 256 )+ rxBuffer->data[2] ;
                                    NewPWM = ReturnValue ;
                            }
                            else    ReturnValue = 0 ;
                    }

                }
            }
        }
    return (ReturnValue);
}

void    Transmit_CAN1_Message(void)
{
     CAN_TX_BUFFER *txBuffer = NULL;    
    
                // CAN0 : Transfer 8 bytes data to CAN Bus 
                memset(txFiFo, 0x00, CAN1_TX_FIFO_BUFFER_ELEMENT_SIZE);
                txBuffer = (CAN_TX_BUFFER *)txFiFo;
                txBuffer->id = WRITE_ID(CAN_TXID);
                txBuffer->dlc = CANLengthToDlcGet(8);
                txBuffer->fdf = 0 ;
                txBuffer->brs = 0 ;
                
                txBuffer->data[0] = 0x55; // Low byte of ADC_Buffer
                txBuffer->data[1] = 0xaa; // High byte of ADC_Buffer
                txBuffer->data[2] = adcResult%256 ;
                txBuffer->data[3] = adcResult/256 ;
                txBuffer->data[4] = 0;
                txBuffer->data[5] = 0;
                txBuffer->data[6] = 0;
                txBuffer->data[7] = 0;
                
                if (CAN1_TxFifoFreeLevelGet())
                {
                 CAN1_MessageTransmitFifo(1, txBuffer);   
                }    
}


/*******************************************************************************
 End of File
*/

